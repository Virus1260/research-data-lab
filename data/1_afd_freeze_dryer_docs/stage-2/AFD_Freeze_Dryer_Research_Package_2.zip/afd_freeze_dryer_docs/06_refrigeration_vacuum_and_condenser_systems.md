# 06 — Refrigeration, Vacuum & Condenser/Material Collector Systems

## 1. The Temperature Control Unit (TCU)

Hosokawa names the TCU explicitly as a standalone subsystem on the AFD page ("Temperature Control Unit (TCU) for thermal management"). Generically, a TCU is a self-contained skid that:
- Houses a **refrigeration circuit** (compressor, condenser, expansion device, evaporator) sized to chill a heat-transfer fluid.
- Houses **electric heating elements** to warm the same fluid loop for the drying phases.
- Circulates that fluid through the process vessel's jacket via a pump, with a control loop (PID, typically) holding jacket temperature to setpoint and ramping it through the cycle's freeze/dry stages.
- **Heat-transfer fluid**: for the wide temperature swing a freeze dryer needs (roughly −55 °C to +40/50 °C or higher for a demanding secondary-drying step), **silicone (dimethyl siloxane) heat-transfer oil** is the industry-standard fluid, used because it stays fluid and stable across that entire range without freezing or excessive viscosity increase at the cold end — this is standard practice on conventional shelf freeze dryers as well and transfers directly.

## 2. Refrigeration system design

- **Cascade refrigeration** — two (or more) separate refrigerant loops connected through an intermediate heat exchanger, where the "low stage" loop's condenser is cooled by the "high stage" loop's evaporator — is the standard architecture whenever a single refrigerant/compressor combination can't efficiently reach the target low temperature (roughly below about −40 °C, where a single-stage vapor-compression cycle's efficiency collapses and compressor discharge temperatures become excessive). This is standard practice on virtually all pharma/lab freeze dryers reaching the −40 °C to −85 °C range typically needed.
- **Natural refrigerants** are increasingly used for the low-temperature stage because of regulatory pressure (Montreal/Kyoto Protocol phase-downs of high-GWP synthetic refrigerants): **ethane** (boiling point −88.5 °C) is specifically cited by GEA as enabling condenser temperatures below −80 °C in an indirect, silicone-oil-cooled arrangement — a genuinely low-global-warming-potential option worth considering for a from-scratch build, alongside more conventional (but higher-GWP) choices like R404A or R507.
- **Direct expansion (DX)** cooling — refrigerant routed straight through a coil in the vessel jacket or condenser — is simpler but uncontrolled: run continuously, it just "bottoms out" at whatever temperature the refrigeration circuit's coldest point reaches, with no fine temperature control. Most pharma-grade systems instead use **indirect cooling**: refrigerant chills the heat-transfer fluid via a heat exchanger, and that fluid (not refrigerant) circulates through the jacket, giving much tighter, controllable temperature regulation (typically ±1 °C on commercial shelf-dryer literature) and simpler sealing (no refrigerant lines running to a moving/agitated vessel).
- **Shared vs. separate refrigeration for the vessel jacket and the condenser**: advanced commercial freeze dryers often use one shared refrigeration plant for both duties (fewer components, better reliability, better energy efficiency, less waste heat) rather than two independent systems — worth designing in from the start rather than retrofitting.

## 3. Vacuum system

### 3a. Pump selection
A typical pharma freeze-dryer vacuum train is **oil-free / dry**, both to avoid oil vapor backstreaming contaminating the sterile product path and because condensable water vapor is hard on oil-sealed pumps. Common architecture, per general vacuum-industry and freeze-drying-specific literature (Edwards Vacuum's own freeze-drying application note):
- A **positive-displacement roots blower** (or dry screw pump) staged ahead of a **backing pump**, in series, is a very common combination — matches the two-(or-more)-stage vacuum pump system Hosokawa's own 2003 patent specifically recommends for a 50 L charge.
- Dry screw pumps and multi-stage Roots/backing-pump combinations are the modern default for pharma freeze-drying, replacing older oil-sealed rotary vane pumps for product-contact-adjacent duty.
- **The vacuum pump pulls through the condenser/material collector, not directly on the product chamber** — this protects the pump from ingesting bulk water vapor and any entrained product dust (both patents and generic literature agree on this arrangement).

### 3b. Pressure instrumentation — and why you need two kinds of gauge
This is one of the more subtle, easy-to-get-wrong parts of the system, and it's worth understanding in some depth because it directly enables in-process end-of-drying detection:
- **Pirani gauge**: measures pressure indirectly via the thermal conductivity of the gas present. Its reading is **gas-composition dependent** — water vapor conducts heat differently than nitrogen/air (about 1.6× the thermal conductivity), so a Pirani gauge reads noticeably (~50-60%) higher than true pressure while the chamber atmosphere is mostly water vapor (i.e., during active primary drying).
- **Capacitance manometer**: measures true absolute pressure via a mechanical diaphragm deflection, and is **not affected by gas composition**.
- **Comparative pressure measurement**: running both gauges on the same chamber and watching the *gap* between their readings converge to a small, near-zero difference is a well-established, widely used method (documented by both Millrock Technology and in the peer-reviewed pharma freeze-drying literature) to detect the **end of primary drying** — when the gap closes, the chamber atmosphere has stopped being dominated by water vapor, meaning sublimation is essentially complete. Best practice (per Patel et al., "Determination of End Point of Primary Drying in Freeze-Drying Process Control," *AAPS PharmSciTech* 11(1), 2010, and reaffirmed in a 2022 industry scale-up best-practices paper in the same journal) is to run both gauge types on **both** the vessel and the condenser/collector side.
- Control loops should regulate chamber pressure using the **capacitance manometer** (true pressure), using the Pirani purely as a secondary/diagnostic signal.

### 3c. Achievable vacuum level
Per file 02/03, the process needs roughly **5 mbar down to 0.01 mbar** (Hosokawa's 2003 patent range) or the narrower **0.1–3 mbar** figure given in the 2020 patent for approaching the sublimation onset — comfortably within the range of a well-selected dry screw + Roots combination, and well short of the deep high-vacuum range (10⁻³ mbar and below) that would require diffusion or turbomolecular pumping. This is a "rough/medium vacuum" system, not a high-vacuum one — an important, cost-relevant distinction when selecting pumps.

## 4. Condenser vs. material collector — don't conflate these

This is a point of genuine nuance the AFD's own patents make clear (file 03):

- **A classic condenser** (refrigerated coil bank, as in a conventional shelf freeze dryer, and as still described as an option in Hosokawa's 2003 patent) works by **freezing water vapor as ice directly onto a cold surface**. It needs periodic defrosting and, per the 2003 patent's own numbers, coil spacing of at least 3-4 cm to tolerate roughly 1 cm of ice buildup before that's required. A dual-condenser arrangement (one online, one defrosting) supports continuous operation.
- **The AFD's material collector** (per the 2020 patent, NL2026893B1) is functionally a **filter housing that traps dry powder dust** from the vapor stream on its way to the vacuum pump — it is not primarily a water-vapor condensing surface. Given the AFD dries a granular/powder bed rather than a static cake, a meaningful fraction of what leaves the vessel in the vapor stream is fine product dust entrained in the water vapor, not just water vapor alone — hence a *filter* (with blowback purge and a heated collection hopper below it) is the more critical downstream component for this specific architecture, layered with (not necessarily replacing) a conventional condenser/cold trap further downstream to actually capture the water vapor itself before it reaches the pump.
- **For your own build**, a sound approach combining both patents' teaching is: material collector (filter + valve/bypass, per NL2026893B1) immediately downstream of the vessel to catch product dust and control ice-particle recirculation, **followed by** a conventional refrigerated condenser coil (per NL1022668C2) to actually condense the bulk of the water vapor before it reaches the vacuum pump, protecting the pump from moisture load. This two-stage arrangement is consistent with, and a reasonable synthesis of, what both patents separately disclose.

## 5. Valve requirements on the vacuum path

- **Isolation valve** between vessel and material collector/condenser — must be vacuum-rated, and per NL2026893B1, ideally able to hold an intermediate ("throttled") position as well as fully open/closed, since the patent's whole recirculation strategy depends on that valve's position changing through the cycle.
- **Bypass line and valve** around the main isolation valve, per the same patent.
- **Vent/break valve** to controllably return the vessel to atmospheric pressure (through a sterile air or nitrogen filter, for aseptic operation) at end of cycle.
- All vacuum-side valves need bellows-sealed or diaphragm-sealed stems (not simple packed-gland stems) to avoid becoming the system's dominant leak path — standard vacuum-engineering practice, not AFD-specific.
