# 03 — What Is Actually Hosokawa/AFD-Specific vs. Generic Pharma Freeze-Drying

This is the chapter to read most carefully. Getting this distinction right determines whether the rest of your build effort is well-aimed.

## 1. What Hosokawa's own page tells you (verbatim facts, paraphrased)

From https://hosokawa-micron-bv.com/technologies/drying/freeze-dryer (fetched September 2026):

- The AFD produces **free-flowing bulk pharmaceutical powder** (antibiotics, hyaluronic acid, injectables, peptides, PLGA) in a **closed, one-pot process**, requiring no operator intervention or post-processing.
- **Principle of operation:** the product is frozen *while being agitated* inside a purpose-built lyophilisation chamber. Whether the feed starts as liquid, granular solid, or paste, agitated freezing solidifies it into free-flowing, snow-like granules. Once fully frozen, sublimation begins; heat supplied through the vessel **jacket** is transferred through the *agitated* product for fast, uniform drying. As ice sublimes, the granules shrink into a fine, loose, dry powder. After vacuum release, the chamber opens and the powder is discharged.
- **Named subsystems** on an AFD system: lyophilisation chamber (product chamber); a **dust filter** to retain product in the chamber; a **vacuum pump skid**; a **Temperature Control Unit (TCU)**; **CIP** facilities; optional **SIP** facilities; a **21 CFR Part 11–compliant control system**; a **Utility Management Skid** (interface to factory utilities); optional customized support/lift; optional contained-operation features; a cGMP documentation package.
- **Available sizes:** models from 1 L to 1,500 L nominal vessel volume, with **max. batch volumes from 0.5 L to 750 L** and **indicative sublimation capacities from 0.1 kg/h (1 L model) to 13.7 kg/h (1,500 L model)** — Hosokawa's own published table, explicitly labeled "indicative values; performance depends on product properties and process parameters. Detailed specifications available on request." Models ≤~20 L are positioned as R&D scale; ≥60 L as GMP manufacturing scale.
- Hosokawa markets a physically separate but related family of pages for the **general vacuum/paddle/conical drying platform** these systems are built from (Conical Screw Dryer, Conical Paddle Dryer, Vacuum Dryers, and the Nauta® conical screw mixer).

**Nothing on the public page states**: exact vessel dimensions, exact wall thickness, exact materials of construction beyond implied stainless steel, exact motor power, exact agitator geometry, exact vacuum pump model/capacity, exact refrigeration capacity or refrigerant, or exact condenser surface area. These are legitimately not public, and this package does not invent them.

## 2. What Hosokawa's own patents tell you (this is where the real engineering detail is)

Patents are the single best public source of engineering detail on a proprietary machine, because a patent must disclose enough for "a person skilled in the art" to actually build the invention. Two Hosokawa Micron B.V. patents are directly on point.

### 2a. NL1022668C2 / EP1601919B1, "Stirred freeze drying" (filed 2003, granted 2004/2012)

This is the foundational patent for the whole "stirred freeze dryer" concept as commercialized by Hosokawa. Key disclosed engineering facts:

- **Vessel geometry:** a vessel with a **downward-conical shape**, with an internal mixing member that rotates with a **small clearance (0.5–15 mm, preferably 1–10 mm) along the inner wall** — close enough to continuously scrape/prevent product from caking onto the wall, without metal-to-metal contact.
- **This conical vessel is explicitly stated to often be part of a conical mixer** — i.e., the same mechanical family as Hosokawa's Nauta® conical screw mixer (see §3 below). The patent also allows a cylindrical vessel with a conical bottom section as an equivalent, space-saving alternative.
- **Freezing method, two options both disclosed:**
  - *Indirect*: circulate a low-temperature coolant through the vessel's jacket.
  - *Direct*: inject liquid nitrogen or solid CO₂ (dry ice) straight into the vessel and mix it with the charge.
- **Disclosed process parameters** (Hosokawa's own numbers, from the patent claims):
  - Optimum freezing rate: **0.1–10 °C/min**.
  - Frozen-charge temperature after freezing: **0 °C to −60 °C**, preferably **−55 °C to −15 °C**.
  - Sublimation vacuum: **5 mbar down to 0.01 mbar**, preferably **<0.1 mbar**.
  - For a 50 L charge, a **two-or-more-stage vacuum pump system** is specifically called out as well-suited.
  - Typical drying time cited: **10–100 hours for a 50 L charge** (illustrative, not a spec).
- **Mixing element options, all disclosed as viable:** a centrally-driven **ribbon** element, a centrally-driven **paddle/blade** element, or an **orbital screw element with a swing arm** (this last one is the Nauta mixer's signature mechanism).
- **Drive/seal options, explicitly to protect vacuum integrity and avoid frozen lubricant:**
  - A **magnetic coupling** between the external motor and the internal mixer, so there is no shaft penetration through the vessel wall at all (best for minimizing vacuum leak paths).
  - Alternatively, a single rotating shaft seal if a direct-drive shaft does penetrate the wall.
  - Drive bearings are placed **outside the vessel wall**, specifically to prevent lubricant from freezing and seizing at cryogenic vessel temperatures.
- **Condenser arrangement, several configurations disclosed:**
  - Condenser mounted directly above the vessel, or placed beside/next to it (to avoid product splashing/entrainment reaching the cold coils).
  - Cooling coil spacing of at least **3–4 cm**, sized so that up to roughly **1 cm of ice buildup** on the coils is tolerable before defrost is needed.
  - A **dual/double condenser** arrangement — one operating while the other is taken offline and defrosted — to allow continuous operation on longer batches.
  - An optional **dust filter with a large surface area** between the vessel and the condenser, to keep product dust out of the condenser; this filter can itself carry a heat exchanger to prevent water vapor condensing on and blinding the filter screen.

### 2b. NL2026893B1 / WO2022103268A1, "Freeze dryer and method for freeze drying" (filed 2020, granted 2022)

This is very likely the specific patent referenced in Hosokawa's own news release "New Patent for Active Freeze Dryer," which states the key innovation is *"the options for choosing where the dried product is collected, such as at the bottom of the dryer or in the filter."* That description matches this patent closely. Key disclosed engineering facts:

- **The core problem this patent solves:** in the 2003-generation design, product that finishes drying early still sits in the vessel, continuing to be agitated for the entire remaining cycle — bad for shear-sensitive products (the patent specifically names **probiotics/live cells** and **PLGA-based spherical particle formulations**) and inefficient, because dried material keeps occupying heat-transfer wall area that wet material could otherwise use.
- **The solution:** a **material collector** — essentially a filter housing — placed *outside* the vessel, in the vacuum line between the vessel and the vacuum pump, either mounted beside the conical vessel or directly on top of it.
- **A valve between the vessel and the material collector**, with three positions (open / closed / throttled), paired with a **bypass conduit** around that valve. The clever part: 
  - Early in the cycle (freezing and the start of sublimation), the valve is **open**, so any fine ice particles briefly entrained in the vapor flow toward the collector fall straight back down into the vessel under gravity instead of being trapped.
  - As drying proceeds and more of the charge finishes drying (releasing fine powdery dust rather than ice), the valve **closes**, forcing the dust-laden vapor to detour through the bypass line to the filter, where the filter screen catches the dry powder and the vapor continues on to the vacuum pump. The valve, now closed, doubles as a temporary shelf that catches whatever powder falls off the filter.
  - At the end of the cycle, the valve **reopens**, returning the collected dry powder to the vessel for a short **post-blending** step so the whole batch discharges as one uniform lot.
- **Filter blowback ("purge") system:** a purge-gas inlet upstream of the filter provides a reverse blast to dislodge caked powder off the filter screen, dropping it into a heated, double-jacketed **collected-material recipient** below the filter housing, where it can continue drying gently before final discharge.
- **Blow nozzles in the vessel lid**, fed from a gas source (air or nitrogen), used to give a short intermittent gas pulse near the end of the cycle to dislodge any remaining product stuck to the vessel's inner wall or to the agitator, pushing it toward the material collector.
- **Bottom discharge**: a "releasable outlet" at the bottom of the cone — the patent's own drawings describe this as a **ball segment valve** type — normally closed, opened for full product discharge at end of cycle.
- **Sensors/fittings called out on the lid** in the worked example: an illumination source, a vent valve, and a **sight glass** — all mounted through dedicated attachment flanges on the top lid.
- **Suitable pressure for approaching sublimation, per this later patent:** roughly **0.1–3 mbar**, consistent with (slightly narrower than) the 2003 patent's broader 5–0.01 mbar range — the actual operating point depends on product and process.

### 2c. What this tells you about the AFD's real mechanical architecture

Putting the two patents together, a faithful (non-Hosokawa-branded) equivalent machine is:

1. A **jacketed, downward-conical vessel** (a Nauta-style conical mixer body), double-jacketed for both heating and cooling of the wall.
2. An internal **orbiting-screw or ribbon/paddle agitator**, running with a small (single-digit mm) wall clearance, driven from the top through either a magnetically-coupled seal-less drive or a single rotary shaft seal, with bearings kept outside the cold zone.
3. A **bottom discharge valve** (ball-segment type) for full product dump.
4. A **vacuum line off the top of the vessel** leading to an external **material collector / filter housing**, itself equipped with a filter-blowback purge system and a heated collection hopper below it.
5. A **valve + bypass loop** between vessel and collector, to let ice particles recirculate early in the cycle and only route dust to the filter once real drying/powder release has started.
6. A **vacuum pump train** downstream of the collector (this package's file 06 covers pump selection).
7. Optional blow nozzles in the lid for end-of-cycle cleanup.
8. A **TCU** circulating heat-transfer fluid through the vessel jacket for both the cooling (freezing) and heating (sublimation-driving) phases.
9. **CIP spray devices** inside the vessel and lid (rotational spray nozzles, per the earlier patent's description) and, optionally, **SIP** (steam) capability for full sterilization.

That is a buildable machine architecture, described almost entirely in Hosokawa's own patent language — which is exactly why this package leans on it heavily for files 04–08 below, always distinguishing "this is what the patents disclose" from "this is generic engineering practice I'm applying to fill the gaps."

## 3. The Nauta® mixer connection — your best real-world reference platform

Hosokawa's Nauta® conical screw mixer page (https://hosokawa-micron-bv.com/technologies/mixing/nauta-conical-screw-mixer) independently confirms the mechanical family: a **conical vessel with an orbiting, cantilevered screw**, low-shear, available with **heating/cooling/drying (including under vacuum) capability**, a **bottom discharge valve**, optional **CIP/SIP**, and available in sizes from **5 L to 100,000 L**. Hosokawa's own published Nauta size table (indicative, not AFD-specific) gives a useful sense of scale-vs-vessel-geometry relationships:

| Nominal size | Vessel diameter | Vessel height | Height incl. motor | Typical motor power |
|---|---|---|---|---|
| 500 L | 145 cm | 175 cm | 225 cm | 2.2 kW |
| 1,000 L | 180 cm | 225 cm | 290 cm | 5.5 kW |
| 2,000 L | 210 cm | 280 cm | 350 cm | 7.5 kW |
| 5,000 L | 285 cm | 380 cm | 470 cm | 15 kW |

*(This table is for the general-purpose Nauta mixer product line, not the AFD specifically — Hosokawa does not publish AFD vessel dimensions or motor sizes. It is included here only to show a real, citable diameter/height/power scaling relationship for conical vessels of this general type, useful as a sanity check when you size your own much smaller unit in file 11.)* Typical Nauta screw speed is **~70 rpm**, orbiting-arm speed **1–2 rpm**, screw tip speed **0.5–2 m/s** — again, general Nauta figures, not AFD-specific, but a reasonable starting point since the AFD's agitator serves an analogous wall-scraping function (and the freeze-drying patents specify a much gentler mixing action is sufficient, given how slow the drying process is — see file 02 §6 and file 05).

## 4. Generic pharma freeze-drying literature that does *not* directly describe the AFD

Be aware that the overwhelming majority of published pharma freeze-drying material — the Pikal heat/mass-transfer model, most vendor literature (GEA, SP Scientific/Millrock, IMA Life, Telstar, Cuddon), most "how lyophilizers work" explainer content, and essentially all cheap/surplus lab freeze-dryer hardware — describes the **static tray/shelf design**: a rectangular chamber, a stack of flat hollow shelves carrying circulated heat-transfer fluid, vials or trays sitting motionless on the shelves, and a separate ice condenser chamber (often in a "doghouse" alongside or below the main chamber) connected through a duct and isolation valve.

This generic shelf-dryer knowledge is still valuable and is used throughout this package for:
- The underlying **physics** (file 02) — identical regardless of mechanical architecture.
- **Standards and validation practice** (files 05, 09, 10, 14) — GMP, ASME BPE, IQ/OQ/PQ apply the same way to either architecture.
- **Generic component knowledge** — vacuum pumps, gauges, refrigeration principles, PLC/HMI practice (files 06, 08) — the components themselves don't care which vessel geometry they're attached to.

But it should **not** be mistaken for AFD-specific engineering. Where this package draws on shelf-dryer literature, it says so explicitly, and where the AFD's own patents give a different or more specific answer, that is called out as the AFD-accurate figure to prefer.

## 5. Quick-reference: AFD-family vs. classic shelf/tray dryer

| Feature | Hosokawa AFD (patent-documented) | Classic shelf/tray lyophilizer (generic) |
|---|---|---|
| Vessel shape | Single downward-conical vessel | Rectangular chamber with flat shelf stack |
| Product state during process | Continuously/intermittently agitated, becomes free powder | Static, forms a solid "cake" per vial |
| Freezing method | In-vessel, agitated; jacket cooling and/or direct LN₂/dry-ice injection | On-shelf, static; shelf heat-transfer fluid cooling |
| Heat transfer for drying | Through jacket wall to continuously refreshed agitated bed | Through shelf to static vial bottoms |
| Vapor path | Through an external material collector/filter (with recirculation valve) to vacuum pump | Through duct to a separate ice condenser, then vacuum pump |
| End product | Loose, free-flowing powder, ready to discharge | Solid cake in each vial; needs no milling but is vial-bound |
| Typical named "condenser" | Replaced/supplemented by dust filter + material collector (per 2020 patent); earlier patent still allows a classic condenser | Refrigerated ice-condenser coil bank |
| Best public source | Hosokawa's own patents NL1022668C2, NL2026893B1 | Decades of pharma freeze-drying literature, textbooks, vendor manuals |
